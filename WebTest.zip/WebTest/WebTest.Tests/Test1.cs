﻿using WebTest.Models;

namespace WebTest.Tests
{

    namespace WebTest.Tests
    {
        [TestClass]
        public class AllTests
        {
            [TestMethod]
            public void Order_ValidModel_PassesValidation()
            {
                // Arrange
                var order = new Order
                {
                    Id = 1,
                    StoreId = 1,
                    OrderDate = System.DateTime.Now,
                    Period = "Январь 2024",
                    Status = "Новый"
                };

                // Act & Assert
                Assert.IsTrue(order.StoreId > 0);
                Assert.IsFalse(string.IsNullOrEmpty(order.Period));
                Assert.IsFalse(string.IsNullOrEmpty(order.Status));
            }

            [TestMethod]
            public void Product_ValidModel_PassesValidation()
            {
                // Arrange
                var product = new Product
                {
                    Id = 1,
                    Name = "Test Product",
                    Price = 100.50m,
                    StockQuantity = 10
                };

                // Act & Assert
                Assert.IsFalse(string.IsNullOrEmpty(product.Name));
                Assert.IsTrue(product.Price > 0);
                Assert.IsTrue(product.StockQuantity >= 0);
            }

            [TestMethod]
            public void User_ValidModel_PassesValidation()
            {
                // Arrange
                var user = new User
                {
                    Id = 1,
                    Username = "testuser",
                    Password = "password",
                    RoleId = 1
                };

                // Act & Assert
                Assert.IsFalse(string.IsNullOrEmpty(user.Username));
                Assert.IsFalse(string.IsNullOrEmpty(user.Password));
                Assert.IsTrue(user.RoleId > 0);
            }

            [TestMethod]
            public void OrderItem_ValidModel_PassesValidation()
            {
                // Arrange
                var orderItem = new OrderItem
                {
                    Id = 1,
                    OrderId = 1,
                    ProductId = 1,
                    Quantity = 5
                };

                // Act & Assert
                Assert.IsTrue(orderItem.OrderId > 0);
                Assert.IsTrue(orderItem.ProductId > 0);
                Assert.IsTrue(orderItem.Quantity > 0);
            }

            [TestMethod]
            public void Store_ValidModel_PassesValidation()
            {
                // Arrange
                var store = new Store
                {
                    Id = 1,
                    Name = "Test Store",
                    Addres = "Test Address",
                    ContactPerson = "Test Person"
                };

                // Act & Assert
                Assert.IsFalse(string.IsNullOrEmpty(store.Name));
                Assert.IsFalse(string.IsNullOrEmpty(store.Addres));
                Assert.IsFalse(string.IsNullOrEmpty(store.ContactPerson));
            }

            [TestMethod]
            public void Order_InvalidStoreId_FailsValidation()
            {
                // Arrange
                var order = new Order
                {
                    StoreId = 0, // Invalid
                    Period = "Январь 2024",
                    Status = "Новый"
                };

                // Act & Assert
                Assert.IsFalse(order.StoreId > 0);
            }

            [TestMethod]
            public void Product_EmptyName_FailsValidation()
            {
                // Arrange
                var product = new Product
                {
                    Name = "", // Invalid
                    Price = 100.50m,
                    StockQuantity = 10
                };

                // Act & Assert
                Assert.IsTrue(string.IsNullOrEmpty(product.Name));
            }

            [TestMethod]
            public void User_EmptyUsername_FailsValidation()
            {
                // Arrange
                var user = new User
                {
                    Username = "", // Invalid
                    Password = "password",
                    RoleId = 1
                };

                // Act & Assert
                Assert.IsTrue(string.IsNullOrEmpty(user.Username));
            }

            [TestMethod]
            public void OrderItem_ZeroQuantity_FailsValidation()
            {
                // Arrange
                var orderItem = new OrderItem
                {
                    OrderId = 1,
                    ProductId = 1,
                    Quantity = 0 // Invalid
                };

                // Act & Assert
                Assert.IsFalse(orderItem.Quantity > 0);
            }

            [TestMethod]
            public void BusinessLogic_OrderStatus_ValidTransitions()
            {
                // Arrange
                var validStatuses = new[] { "Новый", "В обработке", "Выполнен", "Отгружен" };

                // Act & Assert
                foreach (var status in validStatuses)
                {
                    Assert.IsFalse(string.IsNullOrEmpty(status));
                    Assert.IsTrue(status.Length > 0);
                }
            }

            [TestMethod]
            public void BusinessLogic_PriceCalculation_Correct()
            {
                // Arrange
                var product = new Product { Price = 100m };
                int quantity = 3;
                decimal expectedTotal = 300m;

                // Act
                decimal actualTotal = product.Price * quantity;

                // Assert
                Assert.AreEqual(expectedTotal, actualTotal);
            }

            [TestMethod]
            public void BusinessLogic_StockValidation_Sufficient()
            {
                // Arrange
                var product = new Product { StockQuantity = 10 };
                int orderedQuantity = 5;

                // Act & Assert
                Assert.IsTrue(product.StockQuantity >= orderedQuantity);
            }

            [TestMethod]
            public void BusinessLogic_StockValidation_Insufficient()
            {
                // Arrange
                var product = new Product { StockQuantity = 3 };
                int orderedQuantity = 5;

                // Act & Assert
                Assert.IsFalse(product.StockQuantity >= orderedQuantity);
            }
        }
    }
}
