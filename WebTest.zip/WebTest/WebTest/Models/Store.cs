﻿namespace WebTest.Models
{
    public class Store
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Addres { get; set; } = string.Empty;
        public string ContactPerson { get; set; } = string.Empty;
    }
}
