﻿namespace WebTest.Models
{
    public class SupplyItem
    {
        public int Id { get; set; }
        public int SupplyId { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
