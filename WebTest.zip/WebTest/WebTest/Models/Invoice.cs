﻿namespace WebTest.Models
{
    public class Invoice
    {
        public int Id { get; set; }
        public int StoreId { get; set; }
        public DateTime IssueDate { get; set; }
    }
}
