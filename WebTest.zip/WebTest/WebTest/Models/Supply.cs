﻿namespace WebTest.Models
{
    public class Supply
    {
        public int Id { get; set; }
        public DateTime SupplyDate { get; set; }
        public string Supplier { get; set; } = string.Empty;
    }
}
