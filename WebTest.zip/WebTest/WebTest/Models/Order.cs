﻿namespace WebTest.Models
{
    public class Order
    {
        public int Id { get; set; }
        public int StoreId { get; set; }
        public DateTime OrderDate { get; set; }
        public string Period { get; set; }
        public string Status { get; set; }
    }
}
