﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WebTest.Attributes;
using WebTest.Data;
using WebTest.Models;


namespace WholesaleWarehouseAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly Database _db;
        public ProductController(Database db) => _db = db;

        // --- GET: api/product
        [HttpGet]
        public IActionResult GetAll()
        {
            var products = new List<Product>();
            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand("SELECT * FROM Product", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                products.Add(new Product
                {
                    Id = (int)reader["Id"],
                    Name = reader["Name"].ToString()!,
                    Price = (decimal)reader["Price"],
                    StockQuantity = (int)reader["StockQuantity"]
                });
            }
            return Ok(products);
        }

        // --- GET: api/product/5
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand("SELECT * FROM Product WHERE Id = @id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                var product = new Product
                {
                    Id = (int)reader["Id"],
                    Name = reader["Name"].ToString()!,
                    Price = (decimal)reader["Price"],
                    StockQuantity = (int)reader["StockQuantity"]
                };
                return Ok(product);
            }

            return NotFound();
        }

        // --- POST: api/product
        [HttpPost]
        public IActionResult Create([FromBody] Product product)
        {
            if (product == null)
                return BadRequest();

            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand(
                "INSERT INTO Product (Name, Price, StockQuantity) VALUES (@name, @price, @qty)", conn);
            cmd.Parameters.AddWithValue("@name", product.Name);
            cmd.Parameters.AddWithValue("@price", product.Price);
            cmd.Parameters.AddWithValue("@qty", product.StockQuantity);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Product added successfully") : StatusCode(500, "Error inserting data");
        }

        // --- PUT: api/product/5
        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Product product)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand(
                "UPDATE Product SET Name=@name, Price=@price, StockQuantity=@qty WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@name", product.Name);
            cmd.Parameters.AddWithValue("@price", product.Price);
            cmd.Parameters.AddWithValue("@qty", product.StockQuantity);
            cmd.Parameters.AddWithValue("@id", id);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Product updated") : NotFound("Product not found");
        }

        // --- DELETE: api/product/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand("DELETE FROM Product WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Product deleted") : NotFound("Product not found");
        }
    }
}
