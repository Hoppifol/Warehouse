﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WebTest.Data;
using WebTest.Models;

namespace WebTest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SupplyItemController : ControllerBase
    {
        private readonly Database _db;
        public SupplyItemController(Database db) => _db = db;

        [HttpGet]
        public IActionResult GetAll()
        {
            var list = new List<SupplyItem>();
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("SELECT * FROM SupplyItem", conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new SupplyItem
                {
                    Id = (int)reader["Id"],
                    SupplyId = (int)reader["SupplyId"],
                    ProductId = (int)reader["ProductId"],
                    Quantity = (int)reader["Quantity"]
                });
            }

            return Ok(list);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("SELECT * FROM SupplyItem WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                var item = new SupplyItem
                {
                    Id = (int)reader["Id"],
                    SupplyId = (int)reader["SupplyId"],
                    ProductId = (int)reader["ProductId"],
                    Quantity = (int)reader["Quantity"]
                };
                return Ok(item);
            }

            return NotFound();
        }

        [HttpPost]
        public IActionResult Create([FromBody] SupplyItem item)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand(
                "INSERT INTO SupplyItem (SupplyId, ProductId, Quantity) VALUES (@supplyId, @productId, @qty)", conn);
            cmd.Parameters.AddWithValue("@supplyId", item.SupplyId);
            cmd.Parameters.AddWithValue("@productId", item.ProductId);
            cmd.Parameters.AddWithValue("@qty", item.Quantity);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("SupplyItem created") : StatusCode(500, "Error creating SupplyItem");
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] SupplyItem item)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand(
                "UPDATE SupplyItem SET SupplyId=@supplyId, ProductId=@productId, Quantity=@qty WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@supplyId", item.SupplyId);
            cmd.Parameters.AddWithValue("@productId", item.ProductId);
            cmd.Parameters.AddWithValue("@qty", item.Quantity);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("SupplyItem updated") : NotFound("SupplyItem not found");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("DELETE FROM SupplyItem WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("SupplyItem deleted") : NotFound("SupplyItem not found");
        }
    }
}
