﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WebTest.Data;
using WebTest.Models;


namespace WholesaleWarehouseAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StoreController : ControllerBase
    {
        private readonly Database _db;
        public StoreController(Database db) => _db = db;

        [HttpGet]
        public IActionResult GetAll()
        {
            var stores = new List<Store>();
            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand("SELECT * FROM Store", conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                stores.Add(new Store
                {
                    Id = (int)reader["Id"],
                    Name = reader["Name"].ToString()!,
                    Addres = reader["Addres"].ToString()!,
                    ContactPerson = reader["ContactPerson"].ToString()!
                });
            }

            return Ok(stores);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("SELECT * FROM Store WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                var store = new Store
                {
                    Id = (int)reader["Id"],
                    Name = reader["Name"].ToString()!,
                    Addres = reader["Addres"].ToString()!,
                    ContactPerson = reader["ContactPerson"].ToString()!
                };
                return Ok(store);
            }

            return NotFound();
        }

        [HttpPost]
        public IActionResult Create([FromBody] Store store)
        {
            if (store == null) return BadRequest();

            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand(
                "INSERT INTO Store (Name, Addres, ContactPerson) VALUES (@name, @addr, @contact)", conn);
            cmd.Parameters.AddWithValue("@name", store.Name);
            cmd.Parameters.AddWithValue("@addr", store.Addres);
            cmd.Parameters.AddWithValue("@contact", store.ContactPerson);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Store created") : StatusCode(500, "Error creating store");
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Store store)
        {
            if (store == null) return BadRequest();

            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand(
                "UPDATE Store SET Name=@name, Addres=@addr, ContactPerson=@contact WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@name", store.Name);
            cmd.Parameters.AddWithValue("@addr", store.Addres);
            cmd.Parameters.AddWithValue("@contact", store.ContactPerson);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Store updated") : NotFound("Store not found");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("DELETE FROM Store WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Store deleted") : NotFound("Store not found");
        }
    }
}
