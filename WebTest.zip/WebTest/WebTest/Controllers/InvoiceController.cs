﻿using WebTest.Attributes;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WebTest.Data;
using WebTest.Models;


namespace WholesaleWarehouseAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InvoiceController : ControllerBase
    {
        private readonly Database _db;
        public InvoiceController(Database db) => _db = db;

        [HttpGet]
        public IActionResult GetAll()
        {
            var list = new List<Invoice>();
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("SELECT * FROM Invoice", conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Invoice
                {
                    Id = (int)reader["Id"],
                    StoreId = (int)reader["StoreId"],
                    IssueDate = (DateTime)reader["IssueDate"]
                });
            }

            return Ok(list);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("SELECT * FROM Invoice WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                var inv = new Invoice
                {
                    Id = (int)reader["Id"],
                    StoreId = (int)reader["StoreId"],
                    IssueDate = (DateTime)reader["IssueDate"]
                };
                return Ok(inv);
            }

            return NotFound();
        }

        [HttpPost]
        public IActionResult Create([FromBody] Invoice inv)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand(
                "INSERT INTO Invoice (IssueDate, StoreId) VALUES (@date, @storeId)", conn);
            cmd.Parameters.AddWithValue("@date", inv.IssueDate);
            cmd.Parameters.AddWithValue("@storeId", inv.StoreId);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Invoice created") : StatusCode(500, "Error creating invoice");
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Invoice inv)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand(
                "UPDATE Invoice SET IssueDate=@date, StoreId=@storeId WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@date", inv.IssueDate);
            cmd.Parameters.AddWithValue("@storeId", inv.StoreId);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Invoice updated") : NotFound("Invoice not found");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("DELETE FROM Invoice WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Invoice deleted") : NotFound("Invoice not found");
        }
    }
}
