﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WebTest.Data;
using WebTest.Models;

namespace WebTest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderItemController : ControllerBase
    {
        private readonly Database _db;
        public OrderItemController(Database db) => _db = db;

        [HttpGet]
        public IActionResult GetAll()
        {
            var list = new List<OrderItem>();
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("SELECT * FROM OrderItem", conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new OrderItem
                {
                    Id = (int)reader["Id"],
                    OrderId = (int)reader["OrderId"],
                    ProductId = (int)reader["ProductId"],
                    Quantity = (int)reader["Quantity"]
                });
            }

            return Ok(list);
        }

        [HttpPost]
        public IActionResult Create([FromBody] OrderItem item)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand(
                "INSERT INTO OrderItem (OrderId, ProductId, Quantity) VALUES (@orderId, @productId, @qty)", conn);
            cmd.Parameters.AddWithValue("@orderId", item.OrderId);
            cmd.Parameters.AddWithValue("@productId", item.ProductId);
            cmd.Parameters.AddWithValue("@qty", item.Quantity);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("OrderItem created") : StatusCode(500, "Error creating OrderItem");
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] OrderItem item)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand(
                "UPDATE OrderItem SET OrderId=@orderId, ProductId=@productId, Quantity=@qty WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@orderId", item.OrderId);
            cmd.Parameters.AddWithValue("@productId", item.ProductId);
            cmd.Parameters.AddWithValue("@qty", item.Quantity);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("OrderItem updated") : NotFound("OrderItem not found");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("DELETE FROM OrderItem WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("OrderItem deleted") : NotFound("OrderItem not found");
        }
    }
}
