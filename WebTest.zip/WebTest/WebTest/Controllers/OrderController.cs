﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WebTest.Data;
using WebTest.Models;


namespace WholesaleWarehouseAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly Database _db;
        public OrderController(Database db) => _db = db;

        [HttpGet]
        public IActionResult GetAll()
        {
            var orders = new List<Order>();
            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand("SELECT * FROM [Order]", conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                orders.Add(new Order
                {
                    Id = (int)reader["Id"],
                    StoreId = (int)reader["IdStore"],
                    OrderDate = (DateTime)reader["OrderDate"],
                    Period = reader["Period"].ToString()!,
                    Status = reader["Status"].ToString()!
                });
            }

            return Ok(orders);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand("SELECT * FROM [Order] WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                var order = new Order
                {
                    Id = (int)reader["Id"],
                    StoreId = (int)reader["IdStore"],
                    OrderDate = (DateTime)reader["OrderDate"],
                    Period = reader["Period"].ToString()!,
                    Status = reader["Status"].ToString()!
                };
                return Ok(order);
            }

            return NotFound();
        }

        [HttpPost]
        public IActionResult Create([FromBody] Order order)
        {
            if (order == null) return BadRequest();

            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand(
                "INSERT INTO [Order] (OrderDate, Period, IdStore, Status) VALUES (@date, @period, @store, @status)",
                conn);
            cmd.Parameters.AddWithValue("@date", order.OrderDate);
            cmd.Parameters.AddWithValue("@period", order.Period);
            cmd.Parameters.AddWithValue("@store", order.StoreId);
            cmd.Parameters.AddWithValue("@status", order.Status);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Order created") : StatusCode(500, "Error creating order");
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Order order)
        {
            if (order == null) return BadRequest();

            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand(
                "UPDATE [Order] SET OrderDate=@date, Period=@period, IdStore=@store, Status=@status WHERE Id=@id",
                conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@date", order.OrderDate);
            cmd.Parameters.AddWithValue("@period", order.Period);
            cmd.Parameters.AddWithValue("@store", order.StoreId);
            cmd.Parameters.AddWithValue("@status", order.Status);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Order updated") : NotFound("Order not found");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand("DELETE FROM [Order] WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Order deleted") : NotFound("Order not found");
        }
    }
}
