﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WebTest.Data;
using WebTest.Models;


namespace WholesaleWarehouseAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SupplyController : ControllerBase
    {
        private readonly Database _db;
        public SupplyController(Database db) => _db = db;

        // ✅ Получить все поставки
        [HttpGet]
        public IActionResult GetAll()
        {
            var supplies = new List<Supply>();
            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand("SELECT * FROM Supply", conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                supplies.Add(new Supply
                {
                    Id = (int)reader["Id"],
                    SupplyDate = (DateTime)reader["SupplyDate"],
                    Supplier = reader["Supplier"].ToString()!
                });
            }

            return Ok(supplies);
        }

        // ✅ Получить поставку по ID
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand("SELECT * FROM Supply WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                var supply = new Supply
                {
                    Id = (int)reader["Id"],
                    SupplyDate = (DateTime)reader["SupplyDate"],
                    Supplier = reader["Supplier"].ToString()!
                };
                return Ok(supply);
            }

            return NotFound();
        }

        // ✅ Создать поставку
        [HttpPost]
        public IActionResult Create([FromBody] Supply supply)
        {
            if (supply == null) return BadRequest();

            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand(
                "INSERT INTO Supply (SupplyDate, Supplier) VALUES (@date, @supplier)", conn);
            cmd.Parameters.AddWithValue("@date", supply.SupplyDate);
            cmd.Parameters.AddWithValue("@supplier", supply.Supplier);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Supply created") : StatusCode(500, "Error creating supply");
        }

        // ✅ Обновить поставку
        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Supply supply)
        {
            if (supply == null) return BadRequest();

            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand(
                "UPDATE Supply SET SupplyDate=@date, Supplier=@supplier WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@date", supply.SupplyDate);
            cmd.Parameters.AddWithValue("@supplier", supply.Supplier);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Supply updated") : NotFound("Supply not found");
        }

        // ✅ Удалить поставку
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            using var cmd = new SqlCommand("DELETE FROM Supply WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("Supply deleted") : NotFound("Supply not found");
        }
    }
}
