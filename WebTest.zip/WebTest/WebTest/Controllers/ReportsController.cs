﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WebTest.Data;

namespace WebTest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReportsController : ControllerBase
    {
        private readonly Database _db;
        public ReportsController(Database db) => _db = db;

        [HttpGet("orders-by-product")]
        public IActionResult GetOrdersByProduct()
        {
            var result = new List<object>();
            using var conn = _db.GetConnection();
            conn.Open();

            string sql = @"
                SELECT p.Name, SUM(oi.Quantity) AS TotalOrdered
                FROM [OrderItem] oi
                JOIN [Order] o ON oi.OrderId = o.Id
                JOIN [Product] p ON oi.ProductId = p.Id
                WHERE MONTH(o.OrderDate) = MONTH(GETDATE()) 
                  AND YEAR(o.OrderDate) = YEAR(GETDATE())
                GROUP BY p.Name";

            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                result.Add(new
                {
                    Product = reader["Name"].ToString(),
                    Quantity = (int)reader["TotalOrdered"]
                });
            }

            return Ok(result);
        }

        [HttpGet("shipped-to-stores")]
        public IActionResult GetShippedToStores()
        {
            var result = new List<object>();
            using var conn = _db.GetConnection();
            conn.Open();

            string sql = @"
                SELECT s.Name AS Store, p.Name AS Product, SUM(ii.Quantity) AS TotalShipped
                FROM InvoiceItem ii
                JOIN Invoice i ON ii.InvoiceId = i.Id
                JOIN Store s ON i.StoreId = s.Id
                JOIN Product p ON ii.ProductId = p.Id
                GROUP BY s.Name, p.Name";

            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                result.Add(new
                {
                    Store = reader["Store"].ToString(),
                    Product = reader["Product"].ToString(),
                    Quantity = (int)reader["TotalShipped"]
                });
            }

            return Ok(result);
        }

        [HttpGet("stock")]
        public IActionResult GetStock()
        {
            var result = new List<object>();
            using var conn = _db.GetConnection();
            conn.Open();

            string sql = "SELECT Id, Name, StockQuantity FROM Product";
            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                result.Add(new
                {
                    Id = (int)reader["Id"],
                    Name = reader["Name"].ToString(),
                    Stock = (int)reader["StockQuantity"]
                });
            }

            return Ok(result);
        }

        [HttpGet("stores-by-product/{productId}")]
        public IActionResult GetStoresByProduct(int productId)
        {
            var result = new List<object>();
            using var conn = _db.GetConnection();
            conn.Open();

            string sql = @"
                SELECT DISTINCT s.Name AS Store, s.Addres
                FROM [OrderItem] oi
                JOIN [Order] o ON oi.OrderId = o.Id
                JOIN [Store] s ON o.IdStore = s.Id
                WHERE oi.ProductId = @pid";

            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@pid", productId);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                result.Add(new
                {
                    Store = reader["Store"].ToString(),
                    Address = reader["Addres"].ToString()
                });
            }

            return Ok(result);
        }

        [HttpGet("store-info-by-product/{productId}")]
        public IActionResult GetStoreInfoByProduct(int productId)
        {
            var result = new List<object>();
            using var conn = _db.GetConnection();
            conn.Open();

            string sql = @"
                SELECT DISTINCT s.Id, s.Name, s.Addres, s.ContactPerson
                FROM [OrderItem] oi
                JOIN [Order] o ON oi.OrderId = o.Id
                JOIN [Store] s ON o.IdStore = s.Id
                WHERE oi.ProductId = @pid";

            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@pid", productId);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                result.Add(new
                {
                    Id = (int)reader["Id"],
                    Name = reader["Name"].ToString(),
                    Address = reader["Addres"].ToString(),
                    Contact = reader["ContactPerson"].ToString()
                });
            }

            return Ok(result);
        }

        [HttpGet("needed-restock")]
        public IActionResult GetNeededRestock()
        {
            var result = new List<object>();
            using var conn = _db.GetConnection();
            conn.Open();

            string sql = @"
                SELECT p.Name, 
                       SUM(oi.Quantity) AS Ordered,
                       p.StockQuantity,
                       CASE WHEN p.StockQuantity < SUM(oi.Quantity)
                            THEN SUM(oi.Quantity) - p.StockQuantity
                            ELSE 0 END AS Needed
                FROM [OrderItem] oi
                JOIN [Order] o ON oi.OrderId = o.Id
                JOIN [Product] p ON oi.ProductId = p.Id
                GROUP BY p.Name, p.StockQuantity
                HAVING p.StockQuantity < SUM(oi.Quantity)";

            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                result.Add(new
                {
                    Product = reader["Name"].ToString(),
                    Ordered = (int)reader["Ordered"],
                    InStock = (int)reader["StockQuantity"],
                    Needed = (int)reader["Needed"]
                });
            }

            return Ok(result);
        }

        [HttpGet("invoice-details/{invoiceId}")]
        public IActionResult GetInvoiceDetails(int invoiceId)
        {
            var result = new List<object>();
            using var conn = _db.GetConnection();
            conn.Open();

            string sql = @"
                SELECT p.Name, ii.Quantity
                FROM InvoiceItem ii
                JOIN Product p ON ii.ProductId = p.Id
                WHERE ii.InvoiceId = @iid";

            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@iid", invoiceId);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                result.Add(new
                {
                    Product = reader["Name"].ToString(),
                    Quantity = (int)reader["Quantity"]
                });
            }

            return Ok(result);
        }

        [HttpGet("order-details/{orderId}")]
        public IActionResult GetOrderDetails(int orderId)
        {
            var result = new List<object>();
            using var conn = _db.GetConnection();
            conn.Open();

            string sql = @"
                SELECT p.Name, oi.Quantity
                FROM OrderItem oi
                JOIN Product p ON oi.ProductId = p.Id
                WHERE oi.OrderId = @oid";

            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@oid", orderId);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                result.Add(new
                {
                    Product = reader["Name"].ToString(),
                    Quantity = (int)reader["Quantity"]
                });
            }

            return Ok(result);
        }

        [HttpGet("orders-by-store/{storeId}")]
        public IActionResult GetOrdersByStore(int storeId)
        {
            var result = new List<object>();
            using var conn = _db.GetConnection();
            conn.Open();

            string sql = "SELECT Id, OrderDate, Period, Status FROM [Order] WHERE IdStore = @sid";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@sid", storeId);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                result.Add(new
                {
                    Id = (int)reader["Id"],
                    Date = (DateTime)reader["OrderDate"],
                    Period = reader["Period"].ToString(),
                    Status = reader["Status"].ToString()
                });
            }

            return Ok(result);
        }

        [HttpGet("unsold-products")]
        public IActionResult GetUnsoldProducts()
        {
            var result = new List<object>();
            using var conn = _db.GetConnection();
            conn.Open();

            string sql = @"
                SELECT p.Name
                FROM Product p
                WHERE p.Id NOT IN (
                    SELECT DISTINCT oi.ProductId
                    FROM OrderItem oi
                    JOIN [Order] o ON oi.OrderId = o.Id
                    WHERE MONTH(o.OrderDate) = MONTH(GETDATE()) 
                      AND YEAR(o.OrderDate) = YEAR(GETDATE())
                )";

            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                result.Add(new { Product = reader["Name"].ToString() });
            }

            return Ok(result);
        }
    }
}
