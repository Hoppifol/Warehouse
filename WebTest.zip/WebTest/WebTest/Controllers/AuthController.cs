﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WebTest.Attributes;
using WebTest.Data;
using WebTest.Models;

namespace WebTest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Role = "Admin")]
    public class AuthController : ControllerBase
    {
        private readonly Database _db;
        public AuthController(Database db) => _db = db;

        [HttpPost("login")]
        public IActionResult Login([FromBody] User user)
        {
            using var conn = _db.GetConnection();
            conn.Open();

            string sql = @"
                SELECT u.Id, u.Username, u.Password, r.RoleName
                FROM [User] u
                JOIN Role r ON u.RoleId = r.Id
                WHERE u.Username = @username";

            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@username", user.Username);
            using var reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                string dbPassword = reader["Password"].ToString()!;
                if (dbPassword == user.Password)
                {
                    return Ok(new
                    {
                        Id = (int)reader["Id"],
                        Username = reader["Username"].ToString(),
                        Role = reader["RoleName"].ToString()
                    });
                }
            }

            return Unauthorized("Неверный логин или пароль");
        }
    }
}
