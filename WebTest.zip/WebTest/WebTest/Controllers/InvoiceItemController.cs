﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WebTest.Data;
using WebTest.Models;

namespace WebTest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InvoiceItemController : ControllerBase
    {
        private readonly Database _db;
        public InvoiceItemController(Database db) => _db = db;

        [HttpGet]
        public IActionResult GetAll()
        {
            var list = new List<InvoiceItem>();
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("SELECT * FROM InvoiceItem", conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new InvoiceItem
                {
                    Id = (int)reader["Id"],
                    InvoiceId = (int)reader["InvoiceId"],
                    ProductId = (int)reader["ProductId"],
                    Quantity = (int)reader["Quantity"]
                });
            }

            return Ok(list);
        }

        [HttpPost]
        public IActionResult Create([FromBody] InvoiceItem item)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand(
                "INSERT INTO InvoiceItem (InvoiceId, ProductId, Quantity) VALUES (@invoiceId, @productId, @qty)", conn);
            cmd.Parameters.AddWithValue("@invoiceId", item.InvoiceId);
            cmd.Parameters.AddWithValue("@productId", item.ProductId);
            cmd.Parameters.AddWithValue("@qty", item.Quantity);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("InvoiceItem created") : StatusCode(500, "Error creating InvoiceItem");
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] InvoiceItem item)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand(
                "UPDATE InvoiceItem SET InvoiceId=@invoiceId, ProductId=@productId, Quantity=@qty WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@invoiceId", item.InvoiceId);
            cmd.Parameters.AddWithValue("@productId", item.ProductId);
            cmd.Parameters.AddWithValue("@qty", item.Quantity);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("InvoiceItem updated") : NotFound("InvoiceItem not found");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            using var conn = _db.GetConnection();
            conn.Open();
            using var cmd = new SqlCommand("DELETE FROM InvoiceItem WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);

            int rows = cmd.ExecuteNonQuery();
            return rows > 0 ? Ok("InvoiceItem deleted") : NotFound("InvoiceItem not found");
        }
    }
}
