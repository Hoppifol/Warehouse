﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Data.SqlClient;
using System.Text;
using WebTest.Data;

namespace WebTest.Attributes
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class AuthorizeAttribute : Attribute, IAuthorizationFilter
    {
        public string? Role { get; set; } // 👈 добавляем возможность проверки роли

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var db = context.HttpContext.RequestServices.GetService(typeof(Database)) as Database;
            var authHeader = context.HttpContext.Request.Headers["Authorization"].FirstOrDefault();

            if (string.IsNullOrEmpty(authHeader) || !authHeader.StartsWith("Basic "))
            {
                context.Result = new UnauthorizedResult();
                return;
            }

            var encoded = authHeader.Substring("Basic ".Length).Trim();
            var decoded = Encoding.UTF8.GetString(Convert.FromBase64String(encoded));
            var parts = decoded.Split(':');

            if (parts.Length != 2)
            {
                context.Result = new UnauthorizedResult();
                return;
            }

            var username = parts[0];
            var password = parts[1];

            using var conn = db!.GetConnection();
            conn.Open();

            string sql = @"
                SELECT u.Id, r.RoleName 
                FROM [User] u
                JOIN Role r ON u.RoleId = r.Id
                WHERE u.Username=@u AND u.Password=@p";

            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@u", username);
            cmd.Parameters.AddWithValue("@p", password);

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                string userRole = reader["RoleName"].ToString()!;

                // ✅ если указана роль в атрибуте — проверяем
                if (!string.IsNullOrEmpty(Role) && !string.Equals(Role, userRole, StringComparison.OrdinalIgnoreCase))
                {
                    context.Result = new ForbidResult(); // нет доступа
                    return;
                }

                return; // доступ разрешён
            }

            context.Result = new UnauthorizedResult();
        }
    }
}
