﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WebTest.Controllers;

namespace Warehouse
{
    public partial class OtchetWindow : Window
    {
        private readonly HttpClient _client;

        public OtchetWindow(HttpClient client)
        {
            InitializeComponent();
            _client = client;
        }

        private async void ReportSelector_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (ReportSelector.SelectedIndex == -1) return;

            switch (ReportSelector.SelectedIndex)
            {
                case 0:
                    await LoadOrdersByProduct();
                    break;
                case 1:
                    await LoadShippedToStores();
                    break;
                case 2:
                    await LoadStock();
                    break;
                case 3:
                    await LoadUnsoldProducts();
                    break;
            }
        }

        private async Task LoadOrdersByProduct()
        {
            try
            {
                var response = await _client.GetAsync("api/reports/orders-by-product");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var result = JsonSerializer.Deserialize<List<OrdersByProduct>>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    ReportGrid.ItemsSource = result;
                }
                else
                {
                    MessageBox.Show("Ошибка: " + response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private async Task LoadShippedToStores()
        {
            try
            {
                var response = await _client.GetAsync("api/reports/shipped-to-stores");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var result = JsonSerializer.Deserialize<List<ShippedToStores>>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    ReportGrid.ItemsSource = result;
                }
                else
                {
                    MessageBox.Show("Ошибка: " + response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private async Task LoadStock()
        {
            try
            {
                var response = await _client.GetAsync("api/reports/stock");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var result = JsonSerializer.Deserialize<List<StockItem>>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    ReportGrid.ItemsSource = result;
                }
                else
                {
                    MessageBox.Show("Ошибка: " + response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private async Task LoadUnsoldProducts()
        {
            try
            {
                var response = await _client.GetAsync("api/reports/unsold-products");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var result = JsonSerializer.Deserialize<List<UnsoldProduct>>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    ReportGrid.ItemsSource = result;
                }
                else
                {
                    MessageBox.Show("Ошибка: " + response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }
    }
    public class OrdersByProduct
    {
        public string Product { get; set; }
        public int Quantity { get; set; }
    }

    public class ShippedToStores
    {
        public string Store { get; set; }
        public string Product { get; set; }
        public int Quantity { get; set; }
    }

    public class StockItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Stock { get; set; }
    }

    public class UnsoldProduct
    {
        public string Product { get; set; }
    }
}
