﻿using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WebTest.Models;

namespace Warehouse
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private readonly HttpClient _client;

        public MainWindow(HttpClient client, string username)
        {
            InitializeComponent();
            _client = client;
            LoadData();
        }

        private async void LoadData()
        {
            try
            {
                var productResponse = await _client.GetAsync("api/Product");
                if (productResponse.IsSuccessStatusCode)
                {
                    var json = await productResponse.Content.ReadAsStringAsync();
                    var products = JsonSerializer.Deserialize<List<Product>>(json,
                        new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    ProductGrid.ItemsSource = products;
                }

                var storeResponse = await _client.GetAsync("api/Store");
                if (storeResponse.IsSuccessStatusCode)
                {
                    var json = await storeResponse.Content.ReadAsStringAsync();
                    var stores = JsonSerializer.Deserialize<List<Store>>(json,
                        new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    StoreGrid.ItemsSource = stores;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

    }
}