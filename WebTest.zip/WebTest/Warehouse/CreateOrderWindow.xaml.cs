﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WebTest.Models;

namespace Warehouse
{
    /// <summary>
    /// Логика взаимодействия для CreateOrderWindow.xaml
    /// </summary>
    public partial class CreateOrderWindow : Window
    {
        private readonly HttpClient _client;
        private ObservableCollection<OrderItem> OrderItems { get; set; } = new();
        private List<Product> AvailableProducts { get; set; } = new();
        private List<Store> AvailableStores { get; set; } = new();

        public CreateOrderWindow(HttpClient client)
        {
            InitializeComponent();
            _client = client;
            ProductsGrid.ItemsSource = OrderItems;

            LoadStores();
            LoadProducts();
        }

        private async void LoadStores()
        {
            try
            {
                var response = await _client.GetAsync("api/Store");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    AvailableStores = JsonSerializer.Deserialize<List<Store>>(json,
                        new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                    StoreComboBox.ItemsSource = AvailableStores;

                    if (AvailableStores.Any())
                        StoreComboBox.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки магазинов: {ex.Message}");
            }
        }

        private async void LoadProducts()
        {
            try
            {
                var response = await _client.GetAsync("api/Product");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    AvailableProducts = JsonSerializer.Deserialize<List<Product>>(json,
                        new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                    // Настраиваем ComboBox в DataGrid
                    var comboBoxColumn = ProductsGrid.Columns[0] as DataGridComboBoxColumn;
                    comboBoxColumn.ItemsSource = AvailableProducts;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки товаров: {ex.Message}");
            }
        }

        private void AddItem_Click(object sender, RoutedEventArgs e)
        {
            OrderItems.Add(new OrderItem());
        }

        private void RemoveItem_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button?.DataContext is OrderItem item)
            {
                OrderItems.Remove(item);
            }
        }

        private async void CreateOrder_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (StoreComboBox.SelectedValue == null)
                {
                    MessageBox.Show("Выберите магазин!");
                    return;
                }

                if (OrderItems.Count == 0)
                {
                    MessageBox.Show("Добавьте товары в заказ!");
                    return;
                }

                // Проверяем что все товары выбраны
                foreach (var item in OrderItems)
                {
                    if (item.ProductId == 0 || item.Quantity <= 0)
                    {
                        MessageBox.Show("Заполните все товары корректно!");
                        return;
                    }
                }

                int storeId = (int)StoreComboBox.SelectedValue;

                // 1. Создаем заказ
                var order = new Order
                {
                    StoreId = storeId,
                    OrderDate = DateTime.Now,
                    Period = DateTime.Now.ToString("MMMM yyyy"),
                    Status = "Новый"
                };

                var orderJson = JsonSerializer.Serialize(order);
                var orderContent = new StringContent(orderJson, Encoding.UTF8, "application/json");

                var orderResponse = await _client.PostAsync("api/Order", orderContent);

                if (!orderResponse.IsSuccessStatusCode)
                {
                    var error = await orderResponse.Content.ReadAsStringAsync();
                    MessageBox.Show($"Ошибка создания заказа: {error}");
                    return;
                }

                // Получаем ID созданного заказа
                int orderId = await GetLastOrderId(storeId);

                if (orderId == 0)
                {
                    MessageBox.Show("Не удалось получить ID созданного заказа!");
                    return;
                }

                // 2. Добавляем товары в заказ
                bool allItemsAdded = true;
                foreach (var item in OrderItems)
                {
                    var orderItem = new OrderItem
                    {
                        OrderId = orderId,
                        ProductId = item.ProductId,
                        Quantity = item.Quantity
                    };

                    var itemJson = JsonSerializer.Serialize(orderItem);
                    var itemContent = new StringContent(itemJson, Encoding.UTF8, "application/json");

                    var itemResponse = await _client.PostAsync("api/OrderItem", itemContent);

                    if (!itemResponse.IsSuccessStatusCode)
                    {
                        allItemsAdded = false;
                        var error = await itemResponse.Content.ReadAsStringAsync();
                        MessageBox.Show($"Ошибка добавления товара: {error}");
                        break;
                    }
                }

                if (allItemsAdded)
                {
                    MessageBox.Show("Заказ успешно создан!");
                    this.DialogResult = true;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private async Task<int> GetLastOrderId(int storeId)
        {
            try
            {
                var response = await _client.GetAsync($"api/Order");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var orders = JsonSerializer.Deserialize<List<Order>>(json,
                        new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                    return orders?.Where(o => o.StoreId == storeId).Max(o => o.Id) ?? 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка получения ID заказа: {ex.Message}");
            }
            return 0;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}
