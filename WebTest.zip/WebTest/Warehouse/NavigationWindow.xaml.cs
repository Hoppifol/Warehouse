﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Warehouse
{
    public partial class NavigationWindow : Window
    {
        private readonly HttpClient _client;
        private readonly UserResponse _currentUser;

        public NavigationWindow(HttpClient client, UserResponse user)
        {
            InitializeComponent();
            _client = client;
            _currentUser = user;

            // Проверка данных пользователя
            if (_currentUser == null)
            {
                return;
            }

            if (string.IsNullOrEmpty(_currentUser.Role))
            {
                _currentUser.Role = "Customer";
            }

            InitializeUIByRole();
            this.Title = $"Навигация - {_currentUser.Username} ({_currentUser.Role})";
        }

        private void InitializeUIByRole()
        {
            MessageBox.Show($"Роль пользователя: {_currentUser?.Role}");

            // Проверяем все возможные варианты написания
            var role = _currentUser?.Role?.ToLower().Trim();

            // Всегда показываем кнопку списков
            Spiski.Visibility = Visibility.Visible;

            // Логика для кнопок в зависимости от роли (с учетом разных вариантов написания)
            if (role == "admin" || role == "админ" || _currentUser?.Role?.ToLower().Contains("admin") == true)
            {
                Otchet.Visibility = Visibility.Visible;
                CreateOrder.Visibility = Visibility.Visible;
            }
            else if (role == "customer" || role == "клиент" || _currentUser?.Role?.ToLower().Contains("customer") == true)
            {
                Otchet.Visibility = Visibility.Collapsed;
                CreateOrder.Visibility = Visibility.Visible;
            }
            else
            {
                // Для других случаев
                Otchet.Visibility = Visibility.Collapsed;
                CreateOrder.Visibility = Visibility.Collapsed;
            }
        }

        private void Spiski_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow(_client, _currentUser.Username);
            mainWindow.Show();
            this.Close();
        }

        private void Otchet_Click(object sender, RoutedEventArgs e)
        {
            var otchetWindow = new OtchetWindow(_client);
            otchetWindow.ShowDialog();
        }

        private void CreateOrder_Click(object sender, RoutedEventArgs e)
        {
            var createOrderWindow = new CreateOrderWindow(_client);
            createOrderWindow.ShowDialog();
        }
    }
}

