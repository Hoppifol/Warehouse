﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Warehouse
{
    public partial class NavigationWindow : Window
    {
        private readonly HttpClient _client;
        private readonly UserResponse _currentUser;

        public NavigationWindow(HttpClient client, UserResponse user)
        {
            InitializeComponent();
            _client = client;
            _currentUser = user;

            InitializeUIByRole();
            this.Title = $"Навигация - {_currentUser.Username} ({_currentUser.Role})";
        }

        private void InitializeUIByRole()
        {
            if (_currentUser?.Role == "Customer")
            {
                Otchet.Visibility = Visibility.Collapsed;
            }
            else
            {
                Otchet.Visibility = Visibility.Visible;
            }

            MessageBox.Show($"Роль пользователя: {_currentUser?.Role}");
        }

        private void Spiski_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow(_client, _currentUser.Username);
            mainWindow.Show();
            this.Close();
        }

        private void Otchet_Click(object sender, RoutedEventArgs e)
        {
            var otchetWindow = new OtchetWindow(_client);
            otchetWindow.ShowDialog();
        }

        private void CreateOrder_Click(object sender, RoutedEventArgs e)
        {
            var createOrderWindow = new CreateOrderWindow(_client);
            createOrderWindow.ShowDialog();
        }
    }
}

