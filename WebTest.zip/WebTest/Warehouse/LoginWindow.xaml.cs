﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WebTest.Models;

namespace Warehouse
{
    /// <summary>
    /// Логика взаимодействия для LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        private readonly HttpClient _client = new();
        public LoginWindow()
        {
            InitializeComponent();
            _client.BaseAddress = new Uri("https://localhost:7229/");
        }

        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameBox.Text;
            string password = PasswordBox.Password;
            string credentials = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{username}:{password}"));

            _client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Basic", credentials);

            try
            {
                // Проверим доступ к какому-нибудь методу API, например /api/Product
                var response = await _client.GetAsync("api/Product");

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Вход выполнен успешно!");

                    // Откроем главное окно
                    var main = new MainWindow(_client, username);
                    main.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Ошибка входа! Неверные данные или нет доступа.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения: " + ex.Message);
            }
        }
    }
}
