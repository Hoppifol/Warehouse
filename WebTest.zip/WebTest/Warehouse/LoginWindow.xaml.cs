﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WebTest.Models;

namespace Warehouse
{
    public partial class LoginWindow : Window
    {
        private readonly HttpClient _client = new();
        public LoginWindow()
        {
            InitializeComponent();
            _client.BaseAddress = new Uri("https://localhost:7229/");
        }

        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameBox.Text;
            string password = PasswordBox.Password;

            try
            {
                var loginData = new
                {
                    Username = username,
                    Password = password
                };

                var json = JsonSerializer.Serialize(loginData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await _client.PostAsync("api/Auth/login", content);

                if (response.IsSuccessStatusCode)
                {
                    var responseJson = await response.Content.ReadAsStringAsync();
                    var userData = JsonSerializer.Deserialize<UserResponse>(responseJson, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                    MessageBox.Show($"Вход выполнен успешно! Роль: {userData?.Role}");

                    // Создаем HttpClient с Basic аутентификацией
                    var authenticatedClient = new HttpClient();
                    authenticatedClient.BaseAddress = new Uri("https://localhost:7229/");

                    string credentials = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{username}:{password}"));
                    authenticatedClient.DefaultRequestHeaders.Authorization =
                        new AuthenticationHeaderValue("Basic", credentials);

                    // Передаем UserResponse вместо string
                    var nav = new NavigationWindow(authenticatedClient, userData);
                    nav.Show();
                    this.Close();
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"Ошибка входа: {errorContent}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения: " + ex.Message);
            }
        }
    }

    // Класс для десериализации ответа от API
    public class UserResponse
    {
        public int Id { get; set; }
        public string Username { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
    }
}
